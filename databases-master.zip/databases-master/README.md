# DATABASES

Bases de datos ejemplo.

En este repositorio tenemos las bases de datos ejemplo que utilizo en mis cursos de programación.

EUREKABANK
-------------------------------------------------------
Base de datos de una institución financiera.

Para manejar cuentas de ahorro de los clientes.

RECURSOS
-------------------------------------------------------
Base de datos sencilla de recursos humanos.

VENTAS
-------------------------------------------------------
Base de datos de Ventas.

Maneja diferentes formas de tipo de pago.


------------------------------------------------------------

Puede consultar articulos sobre EUREKABANK en http://gcoronelc.blogspot.pe
